const db = require("../models");

const ResourceGroup = db.ResourceGroup;
const Subscription = db.Subscription;

exports.getAllResourceGroups = async (req, res) => {
    try {

        const resourceGroups =
            await ResourceGroup.findAll({
                include: [Subscription]
            });

        res.status(200).json(resourceGroups);

    } catch (error) {

        res.status(500).json({
            message: error.message
        });

    }
};

exports.getResourceGroupById = async (req, res) => {
    try {

        const resourceGroup =
            await ResourceGroup.findByPk(
                req.params.id,
                {
                    include: [Subscription]
                }
            );

        if (!resourceGroup) {
            return res.status(404).json({
                message: "Resource Group not found"
            });
        }

        res.status(200).json(resourceGroup);

    } catch (error) {

        res.status(500).json({
            message: error.message
        });

    }
};

exports.createResourceGroup = async (req, res) => {
    try {

        const resourceGroup =
            await ResourceGroup.create(req.body);

        res.status(201).json(resourceGroup);

    } catch (error) {

        res.status(500).json({
            message: error.message
        });

    }
};

exports.updateResourceGroup = async (req, res) => {
    try {

        const resourceGroup =
            await ResourceGroup.findByPk(
                req.params.id
            );

        if (!resourceGroup) {
            return res.status(404).json({
                message: "Resource Group not found"
            });
        }

        await resourceGroup.update(req.body);

        res.status(200).json(resourceGroup);

    } catch (error) {

        res.status(500).json({
            message: error.message
        });

    }
};

exports.deleteResourceGroup = async (req, res) => {
    try {

        const resourceGroup =
            await ResourceGroup.findByPk(
                req.params.id
            );

        if (!resourceGroup) {
            return res.status(404).json({
                message: "Resource Group not found"
            });
        }

        await resourceGroup.destroy();

        res.status(200).json({
            message:
                "Resource Group deleted successfully"
        });

    } catch (error) {

        res.status(500).json({
            message: error.message
        });

    }
};