const express = require("express");

const router = express.Router();

const authenticateUser =
require("../middleware/authMiddleware");

const authorizeRoles =
require("../middleware/roleMiddleware");

const userController =
    require("../controllers/userController");

router.get(
    "/",
    userController.getAllUsers
);

router.get(
    "/:id",
    userController.getUserById
);

router.post(
    "/",
     authenticateUser,
    authorizeRoles("Admin"),
    userController.createUser
);

router.put(
    "/:id",
    userController.updateUser
);

router.delete(
    "/:id",
     userController.deleteUser
);

module.exports = router;